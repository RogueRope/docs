---
title: "Privacy Policy"
description: "We do not use cookies and we do not collect any personal data."
date: 2021-03-27T19:23:18+02:00
lastmod: 2021-03-27T19:23:18+02:00
draft: true
images: []
---

__TLDR__: We do not use cookies and we do not collect any personal data.

## Website visitors

- No personal information is collected.
- No information is stored in the browser.
- No information is shared with, sent to or sold to third-parties.
- No information is shared with advertising companies.
- No information is mined and harvested for personal and behavioral trends.
- No information is monetized.

## Contact us

[contact us]({{< ref "/docs/practical/contact" >}} "Contact us") if you have any questions.
