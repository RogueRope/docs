---
title : "Rogue Rope Winter: Bottoms Up!"
description: "Rogue Rope Winter: Bottoms Up! is the inaugural edition of an annual convergence that celebrates the art of connection among kinksters. While rope play is a central medium for this exploration, the event is a canvas for a variety of engaging activities that foster intimate bonds."
lead: "Rogue Rope Winter: Bottoms Up! is the inaugural edition of an annual convergence that celebrates the art of connection among kinksters. While rope play is a central medium for this exploration, the event is a canvas for a variety of engaging activities that foster intimate bonds."
date: 2021-03-06T08:47:36+00:00
lastmod: 2021-03-06T08:47:36+00:00
draft: false
images: []
---
