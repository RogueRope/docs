---
title: Read the updates here.
description: " We will also update the announce whatsapp and other channels, but who's
  got time for that? So before you come to the camp, check this page to see if there
  are any important changes of which you shoul be aware."
lead: Here you will get updates, read these before coming to the camp.
date: 2021-03-11T09:19:42.000+01:00
lastmod: 2021-03-11T09:19:42.000+01:00
weight: "50"
contributors:
- HansF
images: []
toc: false

---
We will also update the announce [whatsapp]({{< ref "/docs/practical/contact" >}} "Contact us") and other channels, but who's got time for that? So before you come to the camp, check this page to see if there are any important changes of which you should be aware.