---
title: Covid Update 1
description: "The covid shizzle thing... "
lead: Some covid details are getting out.
date: 2021-04-27T09:19:42.000+01:00
lastmod: 2021-04-27T09:19:42.000+01:00
weight: "45"
contributors:
- HansF
images: []
toc: false

---
There seems to be light at the end of the tunnel. Vaccinations are getting up to speed, self tests are available. It's time to look forward and follow the regulations up close.

Self-tests could become a requirement for setting up events like this, we are not going to be more strict than the law, but need to stay compliant. 

So this means, **if** it becomes a requirement to do on-site testing, we will **need** to comply. Furthermore, we have not budgetted for those tests, so in case we need to do this, we need to find a budget neutral solution.