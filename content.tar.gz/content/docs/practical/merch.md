---
title: Merch!
description: When you order a ticket, you have the option to buy a t-shirt for 25€.
lead: When you order a ticket, you have the option to buy a t-shirt for 25€.
date: 2021-03-13T15:21:01.000+02:00
lastmod: 2021-03-13T15:21:01.000+02:00
draft: false
images: []
menu: 
  docs:
    parent: "practical"
weight: 90
toc: true
---
* Fair and sustainable
* Durable fabrics: 150 g/m²
* Materials: 100% cotton 

## Close-Fitting Tailored T-shirt  
Design under development


## Basic Straight T-shirt 
Design under development

