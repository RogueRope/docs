---
title: Release Statement
description: Rogue Rope is **not** a non-profit organization, but a de facto association (feitelijke vereniging). In short, this means that everything that happens during the event falls under the full responsibility of the event **participants**.
date: 2021-03-13T15:21:01.000+02:00
lastmod: 2021-03-13T15:21:01.000+02:00
images: []
toc: true
lead: ''

---
## Rogue Rope Release Form
to do: Legal shizzle, need to recheck this.
