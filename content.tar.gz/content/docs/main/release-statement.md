---
title: Release Statement
description: Rogue Rope is expliciet géén vzw, maar een feitelijke vereniging, dit
  wil kort gezegd zeggen dat alles wat tijdens de activiteit gebeurt volledig onder
  eigen verantwoordelijkheid van de deelnemers van de activiteit valt.
date: 2021-03-13T15:21:01.000+02:00
lastmod: 2021-03-13T15:21:01.000+02:00
images: []
toc: true
lead: ''

---
## Rogue Rope Release Form

[English version here!]({{<ref "release-statement-en.md" >}})
Legal shizzle, need to recheck this.